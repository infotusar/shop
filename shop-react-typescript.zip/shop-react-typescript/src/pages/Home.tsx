import React from 'react'
import { Product } from '../components/Product'

export const Home = () => {
  return (
	 <div className='home'>
		<h2 className='title'>Products</h2>
		<section className='products'>
			<Product/>
		</section>
	 </div>
  )
}
