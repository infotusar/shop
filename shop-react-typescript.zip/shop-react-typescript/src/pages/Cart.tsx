import React from 'react';
// import { useSelector, useDispatch } from 'react-redux';
import { useAppSelector as useSelector, useAppDispatch as useDispatch } from '../app/hooks';
import { remove } from '../app/cartSlice';

export const Cart = () => {
	const products = useSelector((state) => state.cart);
	const dispatch = useDispatch();

	const clickToRemove = (item: { id: number}) : void => {
		dispatch(remove(item.id));
	}

	return (
		<div className='cart'>
			<h2 className='title'>Cart Page</h2>
			<section className='cart-items'>
				{
					products.map(item => (
						<div key={item.id + Math.random()} className='cartitem' style={{marginBottom: 20}}>
							<img style={{width: 150, height: 150}} src={item.image} alt="cartitem" />
							<div className='cartTag' style={{padding: '10 30',}}>
								<h4>{item.title}</h4>
								<p>Price: ${item.price}</p>
								<button onClick={() => clickToRemove(item)}>Remove Item</button>
							</div>
						</div>
					))
				}
			</section>
		</div>
	)
}
