import React, { useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
import { useAppSelector as useSelector, useAppDispatch as useDispatch } from '../app/hooks';
import { add } from '../app/cartSlice';
import { fetchProducts, STATUS, User } from './../app/productSlice';

export const Product = () => {
	const { data: products, status} = useSelector(state => state.product);
	const dispatch = useDispatch();
	// const [products, setProducts] = useState([]);

	useEffect(() => {

		dispatch(fetchProducts());
		// const getProducts = async () => {
		// 	await fetch('https://fakestoreapi.com/products')
		// 		.then(res=>res.json())
		// 				.then(json=>setProducts(json));
		// }
		// getProducts()
	}, [dispatch]);

	const clickToAdd = (prod: User) : void => {
		dispatch(add(prod));
	}

	if(status === STATUS.LOADING){
		return (
			<h2>Loading...</h2>
		);
	}

	if(status === STATUS.ERROR){
		return (
			<h2>Something went wrong!</h2>
		);
	}

	return (
		<div className='product'>
			{
				products.map(product => (
					<div className='item' key={product.id}>
						<img style={{height: 200, width: 150}} src={product.image} alt="item" />
						<div className='details'>
							<h4>${product.price}</h4>
							<button onClick={() => clickToAdd(product)}>Add to Cart</button>
						</div>
					</div>
				))
			}
		</div>
	)
}
