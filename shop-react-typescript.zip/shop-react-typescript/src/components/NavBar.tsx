import React from 'react'
import { Link } from 'react-router-dom';
// import { useSelector } from 'react-redux';
import { useAppSelector as useSelector } from '../app/hooks';


export const NavBar = () => {

	const selector = useSelector((state) => state.cart)

  	return (
		<div className='NavBar'>
			<div className='Logo'>
				RTRX
			</div>
			<div className='nav'>
				<ul className='menu'>
					<li>
						<Link to='/shop'>Home</Link>
					</li>
					<li>
						<Link to='/cart'>Cart</Link>
					</li>
				</ul>
				<span className='cartCount'>Total item: {selector.length}</span>
			</div>
		</div>
  	)
}
