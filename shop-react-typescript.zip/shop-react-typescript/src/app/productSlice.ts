import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';

export type User = {
	id: number
	title: string
	price: number
	description: string
	category: string
	image: string
	rating: {
		rate: number
		count: number
	}
}

export const STATUS = Object.freeze({
	IDLE: 'idle',
	LOADING: 'loading',
	ERROR: 'error'
})

type InitialState = {
	data: User[],
	status: string
}

const initialState: InitialState = {
	data: [],
	status: STATUS.IDLE
};


const productSlice = createSlice({
	name: 'product',
	initialState,
	reducers: {
		//Don't use api call into this reducers because it calls syncronously 1#
		// setProducts: (state, action: PayloadAction<User[]>) => {
		// 	state.data = action.payload;
		// },
		// setStatus: (state, action) => {
		// 	state.status = action.payload;
		// }
	},
	extraReducers: (builder) => {
		builder
			.addCase(fetchProducts.pending, (state, action) => {
				state.status = STATUS.LOADING;
			})
			.addCase(fetchProducts.fulfilled, (state, action: PayloadAction<User[]>) => {
				state.data = action.payload;
				state.status = STATUS.IDLE;
			})
			.addCase(fetchProducts.rejected, (state, action) => {
				state.status = STATUS.ERROR;
			})
	}
});


// export const { setProducts, setStatus } = productSlice.actions;
export default productSlice.reducer;

// Basic Thunk
// ReduxToolkit Thunk
export const fetchProducts = createAsyncThunk('products/fetch', async () => {
	const res = await fetch('https://fakestoreapi.com/products');
	const data = await res.json();
	return data;
})


// Row Redux Thunk 1#
// export function fetchProducts() {
// 	return async function fetchProductsThunk(dispatch, getState){
// 		dispatch(setStatus(STATUS.LOADING));
// 		try {
// 			const res = await fetch('https://fakestoreapi.com/products');
// 			const data = await res.json();
			
// 			dispatch(setProducts(data));
// 			dispatch(setStatus(STATUS.IDLE));
// 		} catch (error) {
// 			console.error(error);
// 			dispatch(setStatus(STATUS.ERROR));
// 		}
// 	}
// }